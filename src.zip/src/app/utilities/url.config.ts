

export class UrlConfig{

    public LOGIN = 'login'
}