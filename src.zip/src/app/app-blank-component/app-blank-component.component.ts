import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-app-blank-component',
  templateUrl: './app-blank-component.component.html',
  styleUrls: ['./app-blank-component.component.css']
})
export class AppBlankComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
