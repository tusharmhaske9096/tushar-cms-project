// model for edit technician

export class editadmin{
    user_name:any;
    user_email:any;
    user_address: any;
    user_phone: any;
    user_username: any;
    user_password: any;
    user_confirmpassword: any;
    user_id:any;
    toggleBtn : any = 0;
}

export class editLeadadmin{
    complaint_id:any;
    company_name:any;
    customer_name:any
    complaint_desc:any;
    company_address:any;
    customer_mobile:any;
    technicianName:any;
    technician_id:any;
    isAssined:any;
    isShow:any;
    toggleBtn : any = 0;

}