import { Injectable } from '@angular/core';
import { Observable,BehaviorSubject } from 'rxjs';
import { editadmin, editLeadadmin } from '../models/adminModel';


@Injectable({
  providedIn: 'root'
})
export class AdminSharedService {

  constructor() { 
  }

}
 
