export const LeadStatus = {
    0: 'New',
    1: 'Completed',
    2: 'Pending',
    3: 'Failed'
}