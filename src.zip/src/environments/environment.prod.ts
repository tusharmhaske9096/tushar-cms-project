export const environment = {
  production: true,
  BASE_API_URL : "https://cms.tcdsitservices.com/api/v1/"
};
